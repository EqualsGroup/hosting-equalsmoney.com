export { EditPerson } from "./EditPerson";
